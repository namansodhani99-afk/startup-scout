# 🚀 IndiaStartup Scout

Auto-discovers Indian early-stage startup videos on YouTube, extracts structured info (company, founders, LinkedIn, website) using Claude AI.

---

## Architecture

```
YouTube Search (yt-dlp / YouTube API)
        ↓
  Get Transcripts (yt-dlp)
        ↓
  Claude AI Extraction
        ↓
  Flask REST API  ←→  Browser Dashboard
```

---

## Setup

### 1. Install dependencies

```bash
cd backend
pip install flask flask-cors yt-dlp anthropic google-api-python-client
```

### 2. Set environment variables

```bash
# Required
export ANTHROPIC_API_KEY=sk-ant-...

# Optional but recommended (enables better YouTube search)
# Get free key at: https://console.cloud.google.com → YouTube Data API v3
export YOUTUBE_API_KEY=AIza...
```

### 3. Run the backend

```bash
python app.py
# → Running on http://localhost:5000
```

### 4. Open the dashboard

Open `frontend/index.html` in your browser.
The dashboard shows a green dot when the backend is connected.

---

## Usage

### Auto-Discovery
Click **⚡ Start Discovery** — the system will:
1. Search YouTube with 9 preset queries (Indian startup demos, YC India, Shark Tank India, etc.)
2. Download transcripts for each video via `yt-dlp`
3. Send content to Claude AI to extract structured data
4. Display results in real-time on the dashboard

### Manual Scrape
Paste any YouTube URL → click **Extract Startup Info**

### Export
Download all discovered startups as a CSV file.

---

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/health` | Backend health check |
| GET | `/api/startups` | Get all startups (supports `?q=`, `?sector=`, `?stage=`) |
| POST | `/api/scrape` | Scrape a single YouTube URL `{"url": "..."}` |
| POST | `/api/discover` | Start auto-discovery job |
| POST | `/api/discover/stop` | Stop the running job |
| GET | `/api/discover/status` | Poll job progress |
| GET | `/api/export/csv` | Download CSV |
| DELETE | `/api/startups/<video_id>` | Remove a startup |

---

## Customise Search Queries

Edit `SEARCH_QUERIES` in `backend/app.py`:

```python
SEARCH_QUERIES = [
    "Indian startup product demo 2024",
    "India early stage startup founder interview",
    "YC India startup demo day",
    "Shark Tank India startup pitch",
    # Add your own...
]
```

---

## Notes

- **Rate limiting**: The scraper adds a 1-second delay between videos to avoid blocking
- **yt-dlp** must be installed and in your PATH (`pip install yt-dlp`)
- **Data is in-memory** — restoring the server clears the list. For persistence, swap `startups_db` list for SQLite (`import sqlite3`)
- YouTube auto-generated captions availability varies; the system falls back to title + description when captions are unavailable
