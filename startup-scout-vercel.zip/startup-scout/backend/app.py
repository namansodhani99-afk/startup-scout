"""
IndiaStartup Scout — Flask Backend
====================================
Auto-discovers Indian startup videos on YouTube,
extracts transcripts via yt-dlp, then uses Claude AI
to parse company info, founders, LinkedIn, and website.

Setup:
    pip install flask flask-cors yt-dlp anthropic google-api-python-client
    export ANTHROPIC_API_KEY=your_key
    export YOUTUBE_API_KEY=your_key   # optional but recommended
    python app.py
"""

import os
import json
import re
import subprocess
import threading
import time
import logging
from datetime import datetime
from flask import Flask, jsonify, request
from flask_cors import CORS
import anthropic

# ── Optional: YouTube Data API (for search) ──────────────────────────────────
try:
    from googleapiclient.discovery import build as yt_build
    YOUTUBE_API_AVAILABLE = True
except ImportError:
    YOUTUBE_API_AVAILABLE = False

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)

ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
YOUTUBE_API_KEY   = os.environ.get("YOUTUBE_API_KEY", "")

claude = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)

# ── In-memory store (swap for SQLite/Postgres in production) ──────────────────
startups_db: list[dict] = []
job_status: dict = {"running": False, "progress": "", "last_run": None, "found": 0}


# ─────────────────────────────────────────────────────────────────────────────
# 1.  YouTube search
# ─────────────────────────────────────────────────────────────────────────────

SEARCH_QUERIES = [
    "Indian startup product demo 2024",
    "India early stage startup founder interview",
    "India startup pitch deck presentation",
    "YC India startup demo day",
    "Indian startup building product",
    "Indian founder startup story 2024",
    "Bangalore startup demo",
    "Mumbai startup pitch",
    "Shark Tank India startup pitch",
]


def search_youtube_api(query: str, max_results: int = 10) -> list[dict]:
    """Search via YouTube Data API v3."""
    if not YOUTUBE_API_KEY or not YOUTUBE_API_AVAILABLE:
        return []
    youtube = yt_build("youtube", "v3", developerKey=YOUTUBE_API_KEY)
    resp = youtube.search().list(
        q=query,
        part="snippet",
        type="video",
        maxResults=max_results,
        relevanceLanguage="en",
        regionCode="IN",
        videoDuration="short",   # < 4 min — typical demos
    ).execute()
    return [
        {
            "video_id": item["id"]["videoId"],
            "title": item["snippet"]["title"],
            "description": item["snippet"]["description"],
            "channel": item["snippet"]["channelTitle"],
            "published": item["snippet"]["publishedAt"],
        }
        for item in resp.get("items", [])
    ]


def search_youtube_ytdlp(query: str, max_results: int = 8) -> list[dict]:
    """
    Fallback search using yt-dlp (no API key needed).
    yt-dlp can scrape YouTube search results directly.
    """
    cmd = [
        "yt-dlp",
        f"ytsearch{max_results}:{query}",
        "--dump-json",
        "--flat-playlist",
        "--no-warnings",
        "--quiet",
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        videos = []
        for line in result.stdout.strip().splitlines():
            if not line:
                continue
            try:
                item = json.loads(line)
                videos.append({
                    "video_id": item.get("id", ""),
                    "title": item.get("title", ""),
                    "description": item.get("description", ""),
                    "channel": item.get("channel", item.get("uploader", "")),
                    "published": item.get("upload_date", ""),
                })
            except json.JSONDecodeError:
                continue
        return videos
    except (subprocess.TimeoutExpired, FileNotFoundError) as e:
        log.warning(f"yt-dlp search failed: {e}")
        return []


def get_video_transcript(video_id: str) -> str:
    """
    Pull auto-generated subtitles + description via yt-dlp.
    Returns combined text for Claude to analyse.
    """
    url = f"https://www.youtube.com/watch?v={video_id}"
    cmd = [
        "yt-dlp",
        "--write-auto-sub",
        "--sub-lang", "en",
        "--sub-format", "vtt",
        "--skip-download",
        "--dump-json",
        "--no-warnings",
        "--quiet",
        "-o", f"/tmp/yt_{video_id}",
        url,
    ]
    metadata_text = ""
    subtitle_text = ""

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        if result.stdout:
            meta = json.loads(result.stdout.splitlines()[0])
            metadata_text = f"""
Title: {meta.get('title', '')}
Description: {meta.get('description', '')[:3000]}
Channel: {meta.get('channel', meta.get('uploader', ''))}
Tags: {', '.join(meta.get('tags', [])[:20])}
Duration: {meta.get('duration', '')} seconds
"""
    except Exception as e:
        log.warning(f"yt-dlp metadata failed for {video_id}: {e}")

    # Try to read subtitle file
    subtitle_path = f"/tmp/yt_{video_id}.en.vtt"
    if os.path.exists(subtitle_path):
        try:
            raw = open(subtitle_path).read()
            # Strip VTT formatting tags
            cleaned = re.sub(r"<[^>]+>", "", raw)
            cleaned = re.sub(r"\d{2}:\d{2}:\d{2}\.\d{3} --> \S+.*", "", cleaned)
            cleaned = re.sub(r"WEBVTT.*?\n", "", cleaned)
            cleaned = re.sub(r"\n{3,}", "\n\n", cleaned).strip()
            subtitle_text = cleaned[:4000]
            os.remove(subtitle_path)
        except Exception:
            pass

    return (metadata_text + "\n\nTranscript:\n" + subtitle_text).strip()


# ─────────────────────────────────────────────────────────────────────────────
# 2.  Claude extraction
# ─────────────────────────────────────────────────────────────────────────────

EXTRACT_PROMPT = """You are an expert analyst specializing in Indian startup ecosystems.

Analyze the following YouTube video content (title, description, transcript) and extract structured information about the startup featured.

VIDEO CONTENT:
{content}

VIDEO URL: {url}

Extract ONLY if this is clearly about an Indian early-stage startup showcasing a product/service.
If it's NOT about an Indian startup, return: {{"skip": true}}

Return a JSON object with this exact schema (no markdown, no extra text):
{{
  "skip": false,
  "company_name": "string",
  "tagline": "string — one sentence, what they do",
  "sector": "one of: Fintech, Healthtech, Edtech, SaaS, D2C, Agritech, Logistics, Deeptech, Climate, Other",
  "stage": "one of: Pre-seed, Seed, Series A, Unknown",
  "city": "Indian city name or Unknown",
  "description": "2–3 sentence company description",
  "founders": [
    {{
      "name": "Full name",
      "title": "Role e.g. CEO & Co-founder",
      "linkedin": "https://linkedin.com/in/... or empty string"
    }}
  ],
  "website": "https://... or empty string",
  "confidence": "high | medium | low"
}}

Be conservative — only populate fields you are confident about. Use empty strings for unknowns."""


def extract_startup_with_claude(video: dict, transcript: str) -> dict | None:
    """Send video content to Claude and parse structured startup data."""
    content = f"""
Title: {video['title']}
Channel: {video['channel']}
Description: {video['description'][:1500]}

{transcript[:3000]}
""".strip()

    try:
        resp = claude.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=1000,
            messages=[{
                "role": "user",
                "content": EXTRACT_PROMPT.format(
                    content=content,
                    url=f"https://youtube.com/watch?v={video['video_id']}"
                )
            }]
        )
        raw = resp.content[0].text.strip()
        raw = re.sub(r"```json|```", "", raw).strip()
        data = json.loads(raw)

        if data.get("skip"):
            return None

        data["video_id"]    = video["video_id"]
        data["video_title"] = video["title"]
        data["source_url"]  = f"https://youtube.com/watch?v={video['video_id']}"
        data["channel"]     = video["channel"]
        data["scraped_at"]  = datetime.now().isoformat()
        return data

    except Exception as e:
        log.warning(f"Claude extraction failed for {video['video_id']}: {e}")
        return None


# ─────────────────────────────────────────────────────────────────────────────
# 3.  Discovery job
# ─────────────────────────────────────────────────────────────────────────────

def is_duplicate(video_id: str) -> bool:
    return any(s.get("video_id") == video_id for s in startups_db)


def run_discovery_job(queries: list[str] = None, max_per_query: int = 5):
    """
    Full pipeline:
      search → get transcript → Claude extract → store
    Runs in a background thread.
    """
    global job_status
    job_status.update({"running": True, "progress": "Starting discovery...", "found": 0})

    queries = queries or SEARCH_QUERIES
    seen_ids = set()

    for query in queries:
        if not job_status["running"]:
            break

        job_status["progress"] = f"Searching: '{query}'"
        log.info(f"Searching YouTube: {query}")

        # Use API if key available, else yt-dlp
        if YOUTUBE_API_KEY and YOUTUBE_API_AVAILABLE:
            videos = search_youtube_api(query, max_per_query)
        else:
            videos = search_youtube_ytdlp(query, max_per_query)

        for video in videos:
            vid = video["video_id"]
            if not vid or vid in seen_ids or is_duplicate(vid):
                continue
            seen_ids.add(vid)

            job_status["progress"] = f"Analysing: {video['title'][:60]}..."
            log.info(f"Processing video: {vid}")

            transcript = get_video_transcript(vid)
            startup = extract_startup_with_claude(video, transcript)

            if startup:
                startups_db.insert(0, startup)
                job_status["found"] += 1
                log.info(f"✓ Found startup: {startup['company_name']}")

            time.sleep(1)   # be polite to YouTube

    job_status.update({
        "running": False,
        "progress": f"Done. Found {job_status['found']} startups.",
        "last_run": datetime.now().isoformat()
    })
    log.info("Discovery job complete.")


# ─────────────────────────────────────────────────────────────────────────────
# 4.  API Routes
# ─────────────────────────────────────────────────────────────────────────────

@app.route("/api/startups", methods=["GET"])
def get_startups():
    sector = request.args.get("sector")
    stage  = request.args.get("stage")
    q      = request.args.get("q", "").lower()

    results = startups_db
    if sector:
        results = [s for s in results if s.get("sector") == sector]
    if stage:
        results = [s for s in results if s.get("stage") == stage]
    if q:
        results = [s for s in results if
                   q in s.get("company_name", "").lower() or
                   q in s.get("city", "").lower() or
                   q in s.get("sector", "").lower() or
                   any(q in f.get("name", "").lower() for f in s.get("founders", []))]

    return jsonify({"startups": results, "total": len(results)})


@app.route("/api/startups/<video_id>", methods=["DELETE"])
def delete_startup(video_id):
    global startups_db
    startups_db = [s for s in startups_db if s.get("video_id") != video_id]
    return jsonify({"ok": True})


@app.route("/api/scrape", methods=["POST"])
def scrape_single():
    """Scrape a single YouTube URL manually."""
    body = request.get_json() or {}
    url = body.get("url", "").strip()
    if not url:
        return jsonify({"error": "url required"}), 400

    m = re.search(r"(?:v=|youtu\.be/)([A-Za-z0-9_-]{11})", url)
    if not m:
        return jsonify({"error": "Invalid YouTube URL"}), 400

    video_id = m.group(1)
    if is_duplicate(video_id):
        return jsonify({"error": "Already scraped"}), 409

    video = {"video_id": video_id, "title": "", "description": "", "channel": ""}

    # Try to get real metadata
    cmd = ["yt-dlp", "--dump-json", "--quiet", "--no-warnings",
           f"https://youtube.com/watch?v={video_id}"]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if r.stdout:
            meta = json.loads(r.stdout.splitlines()[0])
            video.update({
                "title": meta.get("title", ""),
                "description": meta.get("description", "")[:2000],
                "channel": meta.get("channel", meta.get("uploader", "")),
            })
    except Exception:
        pass

    transcript = get_video_transcript(video_id)
    startup = extract_startup_with_claude(video, transcript)

    if not startup:
        return jsonify({"error": "Could not extract startup info from this video"}), 422

    startups_db.insert(0, startup)
    return jsonify({"startup": startup})


@app.route("/api/discover", methods=["POST"])
def start_discovery():
    """Kick off the background auto-discovery job."""
    if job_status["running"]:
        return jsonify({"error": "Job already running"}), 409

    body = request.get_json() or {}
    queries = body.get("queries", SEARCH_QUERIES)
    max_per = body.get("max_per_query", 5)

    thread = threading.Thread(
        target=run_discovery_job,
        args=(queries, max_per),
        daemon=True
    )
    thread.start()
    return jsonify({"ok": True, "message": "Discovery job started"})


@app.route("/api/discover/stop", methods=["POST"])
def stop_discovery():
    job_status["running"] = False
    return jsonify({"ok": True})


@app.route("/api/discover/status", methods=["GET"])
def discovery_status():
    return jsonify(job_status)


@app.route("/api/sectors", methods=["GET"])
def get_sectors():
    sectors = sorted(set(s.get("sector", "Other") for s in startups_db))
    return jsonify({"sectors": sectors})


@app.route("/api/export/csv", methods=["GET"])
def export_csv():
    import csv, io
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Company", "Tagline", "Sector", "Stage", "City",
                     "Website", "Founders", "LinkedIn URLs",
                     "Video URL", "Confidence", "Scraped At"])
    for s in startups_db:
        writer.writerow([
            s.get("company_name", ""),
            s.get("tagline", ""),
            s.get("sector", ""),
            s.get("stage", ""),
            s.get("city", ""),
            s.get("website", ""),
            "; ".join(f.get("name", "") for f in s.get("founders", [])),
            "; ".join(f.get("linkedin", "") for f in s.get("founders", []) if f.get("linkedin")),
            s.get("source_url", ""),
            s.get("confidence", ""),
            s.get("scraped_at", ""),
        ])
    from flask import Response
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment; filename=india_startups.csv"}
    )


@app.route("/health", methods=["GET"])
def health():
    return jsonify({
        "status": "ok",
        "startups": len(startups_db),
        "anthropic_key": bool(ANTHROPIC_API_KEY),
        "youtube_key": bool(YOUTUBE_API_KEY),
        "yt_dlp": bool(subprocess.run(["which", "yt-dlp"],
                        capture_output=True).returncode == 0)
    })


if __name__ == "__main__":
    log.info("Starting IndiaStartup Scout backend on http://localhost:5000")
    app.run(debug=True, port=5000)
